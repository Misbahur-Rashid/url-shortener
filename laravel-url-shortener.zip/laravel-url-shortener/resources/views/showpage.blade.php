<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>url shortened</title>
</head>

<body>
  <img src="{{url('')}}/thumb.png" alt="">
  <script type="text/javascript">
    window.location = "{{$url}}"; //here double curly bracket
  </script>
</body>

</html>